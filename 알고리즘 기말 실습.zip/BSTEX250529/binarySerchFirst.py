def binSearch(nlist,skey):
    global cnt
    start = 0
    end = len(nlist) - 1

    while(start <= end):
        cnt += 1
        mid = (start + end) // 2
        if skey == nlist[mid]:
            return mid
        elif skey > nlist[mid]:
            start = mid + 1
        else:
            end = mid -1

#전역변수 선언 부분 ##
dataAry, ascSort, descSort=[], [], []
findData = 0
cnt = 0
num = []
keyNum = 0
keyIndex = 0

#main 코드 영역 #
if __name__ == "__main__":
    print("정수 10개를 공백구분으로 입력=")
    for i in range(10):
        print("%d 번째 정수 입력 = " %(i+1))
        su = int(input(""))
        num.append(su)

    ascSort = num[ : ]
    descSort = num[ : ]

    #ascSort.sort(reverse=False)
    ascSort.sort() #오름차순정렬
    #descSort.sort(reverse=True)
    descSort.sort(reverse=True) #내림차순정렬

    print("입력된 정수들 num=", num)
    print("오름차순 정렬된 ascSort =",ascSort)
    print("내림차순 정렬된 descSort =",descSort)

    keyNum = int(input("탐색 정수 입력="))
    #keyIndex = binSearch(num, keyNum)
    keyIndex = binSearch(ascSort, keyNum)

    print("검색된 키값의 index=%d" % keyIndex)
    #print("검색된 키값=%d" %num[keyIndex])
    print("검색된 키값=%d" % ascSort[keyIndex])
    